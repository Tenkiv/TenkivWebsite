Version 1.1 of LabView Drivers for the Tenkiv Tekdaqc.

- - INSTALATION - -

- Follow instructions from http://digital.ni.com/public.nsf/allkb/86256F0E001DA9FD86256F0B0057E6E7?OpenDocument by doing the following.

- Move the Tenkiv_Tekdaqc_Lib.llb to your computer's instr.lib directory.
- - This directory is located inside of the instalation directory for LabView.

- After completely restarting LabView, reopen the program.

- You may now search Functions for the appropriate VI.
- - All VI names are generally prefaced with "TekDAQC"
- - The default location for these VIs is Express/Output/Instrument Drivers/paletteMenu
